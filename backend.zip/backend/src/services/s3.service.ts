import AWS from "aws-sdk";

const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY,
    secretAccessKey: process.env.AWS_SECRET_KEY,
    region: process.env.AWS_REGION
});

export const uploadToS3 = async (file: Buffer, key: string) => {
    const params = {
        Bucket: process.env.AWS_BUCKET!,
        Key: key,
        Body: file,
        ContentType: "application/pdf"
    };

    const data = await s3.upload(params).promise();
    return data.Location;
};