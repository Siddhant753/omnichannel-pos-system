import { OrderRepository } from "../repositories/order.repository";
import InventoryModel from "../models/inventory.model";
import { generateInvoiceAndUpload } from "../utils/invoice.util";

export const createOrderService = async (payload: any) => {
    try {
        const { items, ...orderData } = payload;
        
        const [order] = await OrderRepository.createOrder(orderData);
        const orderItems = items.map((item: any) => ({
            ...item,
            order: order._id
        }))

        await OrderRepository.createOrderItems(orderItems);

        const bulkOps = items.map((item: any) => ({
            updateOne: {
                filter: { productVariant: item.productVariant },
                update: { $inc: { quantity: -item.quantity } }
            }
        }));

        await InventoryModel.bulkWrite(bulkOps)

        const invoiceUrl = await generateInvoiceAndUpload(order, orderItems);
        order.invoiceUrl = invoiceUrl;
        await order.save();

        return order;
    } catch (err: any) {
        throw new err;
    }
}