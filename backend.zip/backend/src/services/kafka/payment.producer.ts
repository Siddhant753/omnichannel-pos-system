import { producer } from "../../config/kafka";

export const sendPaymentEvent = async (data: any) => {
    await producer.connect();
    await producer.send({
        topic: 'payments.success',
        messages: [{ value: JSON.stringify(data) }]
    });
};