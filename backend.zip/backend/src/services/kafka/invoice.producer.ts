import { producer } from "../../config/kafka";

export const sendInvoiceEvent = async (data: any) => {
    await producer.connect();
    await producer.send({
        topic: 'invoice.generate',
        messages: [{ value: JSON.stringify(data) }]
    });
};