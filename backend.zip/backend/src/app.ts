import express from 'express';
import type { Request, Response } from 'express';
import cors from 'cors';
import cookieParser from "cookie-parser";

import authRouter from './routes/auth.routes';
import storeRouter from './routes/store.routes';
import productRouter from './routes/product.routes';
import { rateLimiter } from './middleware/rateLimiter';

const app = express();

app.use(cors({
    credentials: true,
    origin: process.env.FRONTEND_URL
}))

app.use(express.json());
app.use(cookieParser());

app.get('/', (req: Request, res: Response) => {
    res.send({ message: 'Backend running on port ' + process.env.PORT });
})

app.use('/api/auth', rateLimiter({ windowInSeconds: 60, maxRequests: 100 }), authRouter);
app.use('/api/store', rateLimiter({ windowInSeconds: 60, maxRequests: 100 }), storeRouter);
app.use('/api/product', rateLimiter({ windowInSeconds: 60, maxRequests: 100 }), productRouter);

export default app;