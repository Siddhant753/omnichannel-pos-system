import { uploadToS3 } from "../services/s3.service";

export const generateInvoiceAndUpload = async (order: any, items: any[]) => {
    const pdfBuffer = Buffer.from(`Invoice for order ${order._id}`);
    const fileName = `invoices/${order._id}.pdf`;
    const url = await uploadToS3(pdfBuffer, fileName);
    
    return url;
};