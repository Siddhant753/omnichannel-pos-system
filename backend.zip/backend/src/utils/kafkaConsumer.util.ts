import { consumer } from "../config/kafkaConfig";
import ProductVariantModel from "../models/productVariants.model";
import InventoryModel from "../models/inventory.model";

export const startBarcodeConsumer = async () => {
    await consumer.connect();

    await consumer.subscribe({ topic: "barcode-scan", fromBeginning: true });
    await consumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            try {
                if (!message.value) return;
                const event = JSON.parse(message.value.toString());
                const { barcode, storeId } = event;

                const productVariant = await ProductVariantModel.findOne({ barcode }).populate("productId");
                if (!productVariant) {
                    console.error(`Product variant not found for barcode: ${barcode}`);
                    return;
                }

                const inventory = await InventoryModel.findOne({ productVariantId: productVariant._id, storeId }).populate({ path: "productVariantId", populate: { path: "productId" } });

                if (!inventory) {
                    console.error(`Inventory not found for product variant: ${productVariant._id} in store: ${storeId}`);
                    return;
                }
                console.log({ barcode, product: productVariant.productId, stock : inventory?.stock || 0 });
            } catch (err) {
                console.error("Consumer error:", err);
            }
        }
    })
}