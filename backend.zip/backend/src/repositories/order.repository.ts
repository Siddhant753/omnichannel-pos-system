import OrderItemsModel from "../models/orderItems.model";
import OrdersModel from "../models/orders.model";

export const OrderRepository = {
    createOrder: async (orderData: any) => {
        return await OrdersModel.create(orderData);
    },

    createOrderItems: async (orderItemsData: any[]) => {
        return await OrderItemsModel.insertMany(orderItemsData);
    }
}