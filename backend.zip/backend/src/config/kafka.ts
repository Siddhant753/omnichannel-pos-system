// import { Kafka } from "kafkajs";

// // kafka client configuration for barcode scanning integration
// export const kafka = new Kafka({
//     clientId: "POS-System",
//     brokers: ["localhost:9092"],
// });

// export const producer = kafka.producer();
// export const consumer = kafka.consumer({ groupId: "inventory-service-group" });

// export const connectProducer = async () => {
//     await producer.connect();
// }

// export const sendBarcodeEvent = async (barcode: string, storeId: string) => {
//     await producer.send({
//         topic: "barcode-scan",
//         messages: [{
//             key: barcode,
//             value: JSON.stringify({
//                 barcode,
//                 storeId,
//                 scannedAt: new Date(),
//             }),
//         }],
//     });
// };

import { Kafka } from 'kafkajs';

export const kafka = new Kafka({
  clientId: 'pos-system',
  brokers: [process.env.KAFKA_BROKER!]
});

export const producer = kafka.producer();
export const consumer = kafka.consumer({ groupId: 'pos-group' });