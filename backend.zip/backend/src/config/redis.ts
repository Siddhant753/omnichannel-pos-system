import { Redis } from "ioredis";

const redis = new Redis({
    host: process.env.REDIS_HOST || "127.0.0.1",
    port: process.env.REDIS_PORT ? Number(process.env.REDIS_PORT) : 6379,

    maxRetriesPerRequest: 3,
    retryStrategy: (times) => {
        return Math.min(times * 50, 2000); // exponential backoff
    },
});

export default redis;